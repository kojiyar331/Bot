module.exports = function ({ models, api }) {
    const Users = models.use('Users');

    // Get detailed info of a user by ID
    async function getInfo(id) {
        return (await api.getUserInfo(id))[id];
    }

    // Get the user's name by ID
    async function getUserName(id) {
        try {
            if (global.data.userName.has(id)) {
                return global.data.userName.get(id);
            } else if (global.data.allUserID.includes(id)) {
                const name = (await this.getData(id)).name;
                return name || "Facebook User";
            } else {
                return "Facebook User";
            }
        } catch {
            return "Facebook User";
        }
    }

    // Get all users with optional filters and selected attributes
    async function getAll(...args) {
        let filter, attributes;
        for (const arg of args) {
            if (typeof arg !== 'object') throw global.getText("users", "needObjectOrArray");
            if (Array.isArray(arg)) attributes = arg;
            else filter = arg;
        }
        try {
            return (await Users.findAll({ where: filter, attributes }))
                .map(user => user.get({ plain: true }));
        } catch (error) {
            console.error(error);
            throw new Error(error);
        }
    }

    // Get data of a single user by ID
    async function getData(userID) {
        try {
            const data = await Users.findOne({ where: { userID } });
            return data ? data.get({ plain: true }) : false;
        } catch (error) {
            console.error(error);
            throw new Error(error);
        }
    }

    // Update user data; if user does not exist, create a new entry
    async function setData(userID, options = {}) {
        if (typeof options !== 'object' && !Array.isArray(options)) throw global.getText("users", "needObject");
        try {
            const user = await Users.findOne({ where: { userID } });
            if (user) {
                await user.update(options);
                return true;
            } else {
                return await this.createData(userID, options);
            }
        } catch (error) {
            console.error(error);
            throw new Error(error);
        }
    }

    // Delete a user by ID
    async function delData(userID) {
        try {
            const user = await Users.findOne({ where: { userID } });
            if (user) await user.destroy();
            return true;
        } catch (error) {
            console.error(error);
            throw new Error(error);
        }
    }

    // Create a new user entry
    async function createData(userID, defaults = {}) {
        if (typeof defaults !== 'object' && !Array.isArray(defaults)) throw global.getText("users", "needObject");
        try {
            await Users.findOrCreate({ where: { userID }, defaults });
            return true;
        } catch (error) {
            console.error(error);
            throw new Error(error);
        }
    }

    return {
        getInfo,
        getUserName,
        getAll,
        getData,
        setData,
        delData,
        createData
    };
};

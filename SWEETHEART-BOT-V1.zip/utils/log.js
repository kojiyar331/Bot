const themes = [
  'blue', 'dream2', 'dream', 'test', 'fiery', 'rainbow', 'pastel',
  'cristal', 'red', 'aqua', 'pink', 'retro', 'sunlight', 'teen',
  'summer', 'flower', 'ghost', 'hacker'
];

const theme = themes[Math.floor(Math.random() * themes.length)];

// Dummy placeholders (no color)
let co = (text) => text;
let error = (text) => text;

module.exports = (text, type) => {
  switch (type) {
    case "warn":
      process.stderr.write(`[ WARNING ] > ${text}\n`);
      break;
    case "error":
      process.stderr.write(`[ ERROR ] > ${text}\n`);
      break;
    default:
      process.stderr.write(`[ ${String(type).toUpperCase()} ] > ${text}\n`);
      break;
  }
};

module.exports.loader = (data, option) => {
  switch (option) {
    case "warn":
      console.log(`[ WARNING ] > ${data}`);
      break;
    case "error":
      console.log(`[ ERROR ] > ${data}`);
      break;
    default:
      console.log(`[ LOADING ] > ${data}`);
      break;
  }
};

module.exports.load = (data, option) => {
  switch (option) {
    case 'warn':
      console.log(`[ LOGIN ] > ${data}`);
      break;
    case 'error':
      console.log(`[ ERROR ] > ${data}`);
      break;
    default:
      console.log(`[ LOGIN ] > ${data}`);
      break;
  }
};

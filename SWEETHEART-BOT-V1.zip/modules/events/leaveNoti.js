const handleRefresh = require("../../includes/handle/handleRefresh.js");

module.exports.config = {
    name: "leaveNoti",
    eventType: ["log:unsubscribe"],
    version: "1.0.1",
    credits: "KOJA-PROJECT",
    description: "Send a notification when a user leaves the group, with a random gif/image/video",
    dependencies: {
        "fs-extra": "",
        "path": ""
    }
};

module.exports.onLoad = function () {
    const { existsSync, mkdirSync } = require("fs-extra");
    const { join } = require("path");

    const mainPath = join(__dirname, "cache", "leaveGif");
    if (!existsSync(mainPath)) mkdirSync(mainPath, { recursive: true });

    const randomGifPath = join(__dirname, "cache", "leaveGif", "randomgif");
    if (!existsSync(randomGifPath)) mkdirSync(randomGifPath, { recursive: true });

    return;
};

module.exports.run = async function ({ api, event, Users, Threads }) {
    try {
        const { threadID } = event;
        const userId = event.logMessageData.leftParticipantFbId;
        if (userId == api.getCurrentUserID()) return;

        const moment = require("moment-timezone");
        const time = moment.tz("Asia/Karachi").format("DD/MM/YYYY || HH:mm:ss");

        const threadDataCache = global.data.threadData.get(parseInt(threadID));
        const data = threadDataCache || (await Threads.getData(threadID)).data;
        const userData = await Users.getData(event.author);
        const authorName = userData.name || "";
        const name = global.data.userName.get(userId) || await Users.getNameUser(userId);

        const type = (event.author == userId)
            ? "has left the group on their own"
            : `was removed from the group by ${authorName}`;

        let msg = data.customLeave || "{name} {type}\n\nFacebook profile ⬇️\nhttps://www.facebook.com/profile.php?id={iduser}";
        msg = msg.replace(/\{name}/g, name)
                 .replace(/\{type}/g, type)
                 .replace(/\{iduser}/g, userId)
                 .replace(/\{author}/g, authorName)
                 .replace(/\{time}/g, time);

        return new Promise((resolve, reject) => {
            api.sendMessage(msg, threadID, (err) => {
                if (err) reject(err);
                else resolve();
            });
        });
    } catch (error) {
        console.error(error);
    }
};
